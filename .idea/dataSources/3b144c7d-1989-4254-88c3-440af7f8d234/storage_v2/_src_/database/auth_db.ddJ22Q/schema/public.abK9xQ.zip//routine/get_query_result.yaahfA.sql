create function get_query_result(sql_query text)
    returns TABLE(id character varying, name character varying, phone_number character varying, order_count integer, enabled boolean)
    language plpgsql
as
$$ BEGIN     RETURN QUERY         EXECUTE sql_query; END
$$;

alter function get_query_result(text) owner to postgres;

